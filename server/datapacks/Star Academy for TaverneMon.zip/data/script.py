import os
import json

def update_loot_table_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        loot_table = json.load(f)

    # Iterate through the pools and entries to find loot_table types and replace "name" with "value"
    for pool in loot_table.get('pools', []):
        for entry in pool.get('entries', []):
            if entry.get('type') == 'loot_table':
                if 'name' in entry:
                    entry['value'] = entry.pop('name')  # Replace "name" with "value"

    # Save the updated loot table back to the file
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(loot_table, f, indent=2)

def process_directory(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.json'):
                file_path = os.path.join(root, file)
                update_loot_table_file(file_path)
                print(f"Updated: {file_path}")

# Set your directory here
loot_tables_directory = '.'  # Change this to the folder containing your loot table files
process_directory(loot_tables_directory)
